window.addEventListener('DOMContentLoaded', (event) => {
  var slideIndex = 0;
  muestrafoto(slideIndex);
});
  
// Flechas siguiente/anterior foto
function siguientefoto(n) {
  muestrafoto(slideIndex += n);
}
 
// Puntitos
function botonfoto(n) {
  muestrafoto(slideIndex = n);
}
 
function muestrafoto(n) {
  var i;
  slideIndex = n;
  var slides = document.getElementsByClassName("diapositivas"); //la variable slides va a ser un array con todas las fotos
  var dots = document.getElementsByClassName("punto");// la variable dots va a ser un array con los puntitos
  if (n > slides.length) {slideIndex = 1} // cdo estoy en la última foto y clicko siguiente: mostrará la primera (n=4 (>3), pongo n=1)
  if (n < 1) {slideIndex = slides.length} // cdo estoy en la primera foto y clicko anterior: mostrará la última (n=0 (<1), pongo n=3)
  for (i = 0; i < slides.length; i++) { //escondo todas las fotos
	  slides[i].style.display = "none"; 
  }
  slides[slideIndex-1].style.display = "block"; //muestra la foto que toca
  dots[slideIndex-1].className += " active";   //activo el botón que he clickado
}


/* 
// 
document.addEventListener('DOMContentLoaded', function() {
  // Inicializa el índice de la diapositiva en 0
  var slideIndex = 0;
  // Llama a la función mostrarFoto con el índice actual
  mostrarFoto(slideIndex);

  // Función para mostrar la foto en la posición n
  function mostrarFoto(n) {
    var i;
    // Obtiene todas las diapositivas y puntos (dots) en el documento
    var fotos = document.getElementsByClassName("diapositivas");
    var dots = document.getElementsByClassName("punto");
    // Si el índice es mayor al número de diapositivas, reinicia el índice a 1
    if (n > fotos.length) {slideIndex = 1}
    // Si el índice es menor que 1, establece el índice al número total de diapositivas
    if (n < 1) {slideIndex = fotos.length}
    // Oculta todas las diapositivas
    for (i = 0; i < fotos.length; i++) {
        fotos[i].style.display = "none";
    }
    // Elimina la clase "active" de todos los puntos (dots)
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    // Muestra la diapositiva actual y marca como activo el punto correspondiente
    fotos[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
  }

  // Función para mostrar la siguiente o anterior foto
  function siguienteFoto(n) {
    // Llama a la función mostrarFoto con el índice actualizado
    mostrarFoto(slideIndex += n);
  }

  // Función para mostrar una foto específica al hacer clic en un punto (dot)
  function botonFoto(n) {
    // Llama a la función mostrarFoto con el índice establecido al valor n
    mostrarFoto(slideIndex = n);
  }
}); */
