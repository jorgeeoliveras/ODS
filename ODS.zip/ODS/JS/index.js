let indiceImagen = 0;
const diapositivas = document.querySelectorAll('.diapositivas');

function mostrarImagen() {
    diapositivas.forEach((diapositiva, index) => {
        if (index === indiceImagen) {
            diapositiva.style.display = 'block';
        } else {
            diapositiva.style.display = 'none';
        }
    });
}

function cambiarImagen(direccion) {
    indiceImagen += direccion;
    if (indiceImagen < 0) {
        indiceImagen = diapositivas.length - 1;
    } else if (indiceImagen >= diapositivas.length) {
        indiceImagen = 0;
    }
    mostrarImagen();
}

setInterval(() => {
    cambiarImagen(1);
}, 2500);

// Mostrar la primera imagen al cargar la página
mostrarImagen();