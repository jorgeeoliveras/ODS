
const preguntas = [
    {
        pregunta: "¿Tu empresa apoya activamente a empresas lideradas por mujeres?",
        respuestas: [
            {opcion: "Sí, nuestra empresa tiene políticas y programas específicos para apoyar a empresas lideradas por mujeres, promoviendo la igualdad de género.", valor: 5},
            {opcion: "Estamos en proceso de explorar formas de apoyar a empresas lideradas por mujeres, pero aún no hemos implementado programas concretos al respecto.", valor: 3},
            {opcion: "No, nuestra empresa no tiene políticas o programas específicos para apoyar a empresas lideradas por mujeres en este momento.", valor: 2},
            {opcion: "No estoy seguro/a de la política de la empresa en este tema.", valor: 0}
        ]
    },
    {
        pregunta: "¿Tu empresa promueve la igualdad de oportunidades laborales para hombres y mujeres?",
        respuestas: [
            {opcion: "Sí, existe una política clara de igualdad de oportunidades.", valor: 5},
            {opcion: "En su mayoría, pero hay áreas donde se podría mejorar.", valor: 3},
            {opcion: "No hay una política formal, pero se fomenta la igualdad de manera informal.", valor: 2},
            {opcion: "No, hay desigualdades evidentes en las oportunidades laborales.", valor: 0}
        ]
    },
    {
        pregunta: "¿Qué medidas implementáis para promover la igualdad de género en las reuniones, eventos y charlas empresariales?",
        respuestas: [
            {opcion: "Proporcionamos la participación en igualdad de género a todo el personal.", valor: 5},
            {opcion: "Promovemos la participación equitativa de hombres y mujeres en ciertas reuniones y charlas.", valor: 2},
            {opcion: "Se hace la exclusión de cierta parte del personal, debido a su género, en todas las reuniones y charlas.", valor: 2},
            {opcion: "No tomamos medidas específicas.", valor: 0}
        ]
    },
    {
        pregunta: "¿Realizan charlas y conferencias para asegurar la eliminación de estereotipos de género en el desarrollo diario de las actividades de vuestra empresa?",
        respuestas: [
            {opcion: "No realizamos charlas o conferencias para asegurar la eliminación de estereotipos de género.", valor: 0},
            {opcion: "No realizamos charlas o conferencias para asegurar la eliminación de estereotipos de género. Pero tenemos pensado hacerlas en un periodo corto de tiempo.", valor: 2},
            {opcion: "Realizamos una charla o conferencia al año para asegurar la eliminación de estereotipos de género.", valor: 3},
            {opcion: "Realizamos más de una charla o conferencia al año para asegurar la eliminación de estereotipos de género.", valor: 5}
        ]
    },
    {
        pregunta: "¿La información dada al cliente está sesgada por género?",
        respuestas: [
            {opcion: "El trato para los clientes es formal y adecuado para cada uno de ellos, sin tener restricciones por el género y fomentando la importancia de la igualdad de género", valor: 5},
            {opcion: "No se tienen en cuenta diferentes formalidades para el género de cada cliente", valor: 3},
            {opcion: "Según el género no damos ningún tipo de información.", valor: 2},
            {opcion: "Se prioriza un género exclusivo como cliente, buscando la exclusión y desinterés por el otro.", valor: 0}
        ]
    },
    {
        pregunta: "¿Cuál es la proporción de mujeres que ejercen puestos directivos?",
        respuestas: [
            {opcion: "Entre el 100 y el 80% de la dirección", valor: 5},
            {opcion: "De un 50% a un 80%", valor: 3},
            {opcion: "Entre un 20% y un 40%", valor: 2},
            {opcion: "Entre un 0 hasta el 20%", valor: 0}
        ]
    },
    {
        pregunta: "¿Cuál es la proyección para el aumento de mujeres en posiciones de liderazgo para los próximos 5 años?",
        respuestas: [
            {opcion: "Menos del 5%", valor: 0},
            {opcion: "Entre un 5% y un 20%", valor: 2},
            {opcion: "Entre un 20% y un 50%", valor: 3},
            {opcion: "Más de un 50%", valor: 5}
        ]
    },
    {
        pregunta: "¿Qué porcentaje de hombres y mujeres dan servicios asistenciales relacionados con la higiene y la limpieza en su compañía?",
        respuestas: [
            {opcion: "Menos del 50% de mujeres, no existe una distinción marcada entre estas labores para ambos géneros.", valor: 5},
            {opcion: "El 50%, los cargos se encuentran equilibrados", valor: 3},
            {opcion: "El 75% los desarrollan mujeres.", valor: 2},
            {opcion: "El 100% de mujeres.", valor: 0}
        ]
    },
    {
        pregunta: "¿Qué porcentaje de hombres y mujeres dan servicios asistenciales relacionados con el mantenimiento en su compañía?",
        respuestas: [
            {opcion: "Menos del 50% de mujeres, no existe una distinción marcada entre estas labores para ambos géneros.", valor: 0},
            {opcion: "El 50%, los cargos se encuentran equilibrados", valor: 5},
            {opcion: "El 75% los desarrollan mujeres", valor: 3},
            {opcion: "El 100% de mujeres.", valor: 2}
        ]
    },
    {
        pregunta: "¿Qué porcentaje de hombres y mujeres se dedican a la atención al cliente en tu empresa?",
        respuestas: [
            {opcion: "Menos del 50% de mujeres, no existe una distinción marcada entre estas labores para ambos géneros.", valor: 5},
            {opcion: "El 50%, los cargos se encuentran equilibrados", valor: 3},
            {opcion: "El 75% los desarrollan mujeres.", valor: 2},
            {opcion: "El 100% de mujeres.", valor: 0}
        ]
    },
    {
        pregunta: "¿En nuestro equipo de marketing hay igualdad de género en cuanto a representación y oportunidades de liderazgo?",
        respuestas: [
            {opcion: "Sí, hay igualdad de género en cuanto a representación y oportunidades de liderazgo.", valor: 5},
            {opcion: "Hay igualdad de género en cuanto a representación, pero no en cuanto a oportunidades de liderazgo.", valor: 3},
            {opcion: "Hay igualdad de género en cuanto a oportunidades de liderazgo, pero no en cuanto a representación.", valor: 2},
            {opcion: "No hay igualdad de género en cuanto a representación ni a oportunidades de liderazgo.", valor: 0}
        ]
    },
    {
        pregunta: "¿Se han llevado a cabo actividades de formación para aumentar la concienciación de la desigualdad presente en la prestación de determinados servicios?",
        respuestas: [
            {opcion: "Sí, se han llevado a cabo prácticas fomentando la concienciación sobre la igualdad y fueron bien recibidas.", valor: 5},
            {opcion: "Sí, pero no lo suficiente, las prácticas adoptadas fueron bien recibidas pero no vemos una aplicación real en la práctica.", valor: 3},
            {opcion: "Se ha intentado por parte de la empresa pero la propuesta no ha sido bien recibida por la plantilla.", valor: 2},
            {opcion: "No se ha propuesto, ya que la mayoría de los trabajadores y trabajadoras no están cómodos cuando hay un intercambio de roles.", valor: 0}
        ]
    },
    {
        pregunta: "¿Las imágenes publicitarias generadas por tu empresa reflejan roles de género tradicionales?",
        respuestas: [
            {opcion: "No, nunca", valor: 5},
            {opcion: "Sí, pero no nos habíamos fijado en ello", valor: 2},
            {opcion: "Si, de manera intencionada.", valor: 0}
        ]
    },
    {
        pregunta: "¿Crees que la desigualdad de género afecta al funcionamiento de la empresa?",
        respuestas: [
            {opcion: "Sí, y por ello intentamos mejorar", valor: 5},
            {opcion: "Sí, pero no sabemos qué hacer", valor: 3},
            {opcion: "No, no lo sabía", valor: 2},
            {opcion: "No, no lo tengo en cuenta", valor: 0}
        ]
    },
    {
        pregunta: "¿Tu empresa incluye la atención postnatal para ambos géneros cómo derecho del trabajador y trabajadora?",
        respuestas: [
            {opcion: "Sí, y tenemos actividades al respecto", valor: 5},
            {opcion: "Sí, pero sólo tenemos actividades para mujeres", valor: 3},
            {opcion: "No, no lo sabía", valor: 2},
            {opcion: "No, no me interesa.", valor: 0}
        ]
    },
    {
        pregunta: "¿Tu empresa fomenta la igualdad de género a través de la implementación de un lenguaje inclusivo en sus políticas y comunicaciones, considerando aspectos como la diversidad, el respeto y la equidad en la expresión verbal y escrita?",
        respuestas: [
            {opcion: "Sí, el lenguaje inclusivo forma parte de la cultura de nuestra empresa", valor: 5},
            {opcion: "Sí, aunque no tenemos claras las reglas del lenguaje inclusivo", valor: 2},
            {opcion: "No, no me preocupa", valor: 0}
        ]
    },
    {
        pregunta: "¿Ha adoptado su empresa alguna política de conciliación familiar y laboral?",
        respuestas: [
            {opcion: "Sí, hemos adoptado diversas medidas incluidas en la responsabilidad social corporativa", valor: 5},
            {opcion: "Sí, pero todavía trabajamos en mejorarlo", valor: 3},
            {opcion: "No, pero lo estamos estudiando", valor: 2},
            {opcion: "No, nos limitamos a adoptar las medidas recogidas en el estatuto de los trabajadores", valor: 0}
        ]
    },
    {
        pregunta: "¿Tu empresa imparte el protocolo de prevención de riesgos psicosociales a los trabajadores y trabajadoras?",
        respuestas: [
            {opcion: "Sí, hemos adoptado el protocolo de riesgos psicosociales", valor: 5},
            {opcion: "Sí, pero todavía trabajamos en mejorarlo", valor: 3},
            {opcion: "No, pero lo estamos estudiando", valor: 2},
            {opcion: "No, no sabíamos de la necesidad de tener un protocolo de riesgos psicosociales.", valor: 0}
        ]
    },
    {
        pregunta: "¿La empresa tiene establecido un canal de denuncias en caso de vulnerabilidad de la integridad física o psíquica de su personal?",
        respuestas: [
            {opcion: "Si, hemos establecido un canal de denuncias.", valor: 5},
            {opcion: "Si, pero no se ha puesto en práctica", valor: 3},
            {opcion: "No, pero se está discutiendo", valor: 2},
            {opcion: "No, no lo vemos necesario.", valor: 0}
        ]
    },
    {
        pregunta: "¿La resolución del proceso del canal de denuncias se considera ágil y sencillo?",
        respuestas: [
            {opcion: "Sí, desde el primer momento la persona afectada tiene la posibilidad de compartir con un representante su caso, aunque el procedimiento sea más extenso.", valor: 5},
            {opcion: "Sí, en el plazo de una semana la empresa ya toma medidas al respecto.", valor: 3},
            {opcion: "No existe canal de denuncia en nuestra empresa", valor: 2},
            {opcion: "La respuesta al proceso depende del nivel de trabajo.", valor: 0}
        ]
    },
    {
        pregunta: "¿La empresa dispone de algún recurso de atención psicológica para los empleados?",
        respuestas: [
            {opcion: "Sí, tenemos un profesional en la empresa", valor: 5},
            {opcion: "Sí, tenemos un convenio con un profesional externo.", valor: 3},
            {opcion: "No nos lo habíamos planteado, pero creemos que sería necesario.", valor: 2},
            {opcion: "No, no disponemos de este recurso ni lo dispondremos en un futuro.", valor: 0}
        ]
    },
    {
        pregunta: "¿La empresa dispone de algún servicio de guardería para los empleados?",
        respuestas: [
            {opcion: "Sí, tenemos una guardería en la empresa", valor: 5},
            {opcion: "Sí, tenemos un convenio con una guardería cercana", valor: 3},
            {opcion: "No nos lo habíamos planteado, pero creemos que sería necesario.", valor: 2},
            {opcion: "No, no disponemos de este recurso ni lo dispondremos en un futuro.", valor: 0}
        ]
    },
    {
        pregunta: "¿Para un mismo puesto de trabajo, se remunera igual a hombres y mujeres?",
        respuestas: [
            {opcion: "Sí, se remunera según convenio.", valor: 5},
            {opcion: "No, las mujeres están mejor remuneradas.", valor: 0},
            {opcion: "No, los hombres están mejor remunerados.", valor: 0}
        ]
    },
    {
        pregunta: "¿Existe conocimiento sobre el “techo de cristal”?",
        respuestas: [
            {opcion: "Sí y por ello desarrollamos políticas y ofrecemos condiciones laborales que apacigüen este fenómeno.", valor: 5},
            {opcion: "Sí pero no se ha desarrollado ningún protocolo para evitarlo.", valor: 0},
            {opcion: "No tenemos conocimiento sobre ello.", valor: 2}
        ]
    },
    {
        pregunta: "¿A la hora de despedir a un trabajador se tiene en cuenta el género?",
        respuestas: [
            {opcion: "Si, se tienen más facilidades para prescindir de una mujer", valor: 0},
            {opcion: "No, a la hora de tomar una decisión no se tiene en cuenta el sexo", valor: 5},
            {opcion: "Si, es más fácil despedir a alguien si es hombre", valor: 0}
        ]
    },
    {
        pregunta: "Al adquirir un producto o servicio, ¿investiga si la empresa proveedora fomenta la igualdad de género?",
        respuestas: [
            {opcion: "Sí, hacemos un estudio de la empresa para comprobar si fomentan la igualdad.", valor: 5},
            {opcion: "No, pero planeamos en un futuro proceder a investigar a las empresas proveedoras, para contribuir de esta manera a la igualdad de género.", valor: 2},
            {opcion: "No lo tenemos en cuenta.", valor: 0}
        ]
    },
    {
        pregunta: "¿Qué medidas toma tu empresa para prevenir el mobbing por motivos de género?",
        respuestas: [
            {opcion: "Si, tenemos un plan específico para prevenir el mobbing por motivos de géneros, conocidos por todos los empleados", valor: 5},
            {opcion: "Sí, implementamos el plan preestablecido por la agenda 2030", valor: 3},
            {opcion: "No, creemos innecesario establecer ningún plan anti mobbing de género", valor: 0}
        ]
    },
    {
        pregunta: "¿Existen horarios de trabajos flexibles para todos en tu empresa?",
        respuestas: [
            {opcion: "La jornada laboral está adaptada a las necesidades de los empleados", valor: 5},
            {opcion: "La jornada laboral tiene una jornada con márgenes para entrada y salida", valor: 3},
            {opcion: "No tenemos ninguna modalidad de horarios flexibles", valor: 0}
        ]
    },
    {
        pregunta: "¿La empresa contrata y/o promueve a los trabajadores por talento y méritos propios?",
        respuestas: [
            {opcion: "Sí, la empresa únicamente contrata y/o promueve a los trabajadores por su valía y no tiene en cuenta otros factores como el género, raza, religión, etc.", valor: 5},
            {opcion: "Sí, pero a veces otros factores influyen en la decisión", valor: 3},
            {opcion: "No, otros factores como el género influyen directamente en las decisiones de contratación y/o promoción", valor: 0}
        ]
    },
    {
        pregunta: "¿La empresa ofrece formación continua a todos los empleados?",
        respuestas: [
            {opcion: "Sí, ofrecemos formación continua para todos los empleados, independientemente de su género", valor: 5},
            {opcion: "Sí, pero esta formación puede ser exclusiva para un género", valor: 3},
            {opcion: "No, no ofrecemos formación continua", valor: 0}
        ]
    },
    {
        pregunta: "¿La empresa ofrece facilidades para la conciliación de la vida personal y laboral?",
        respuestas: [
            {opcion: "Sí, ofrecemos diversas facilidades para la conciliación de la vida personal y laboral, independientemente del género del empleado", valor: 5},
            {opcion: "Sí, pero estas facilidades pueden ser exclusivas para un género", valor: 3},
            {opcion: "No, no ofrecemos facilidades para la conciliación de la vida personal y laboral", valor: 0}
        ]
    },
    {
        pregunta: "¿Se promueve activamente la diversidad de género en las áreas de ciencia, tecnología, ingeniería y matemáticas (STEM) en tu empresa?",
        respuestas: [
            {opcion: "Sí, promovemos activamente la diversidad de género en las áreas de STEM", valor: 5},
            {opcion: "Sí, pero no de manera activa", valor: 3},
            {opcion: "No, no se promueve activamente la diversidad de género en las áreas de STEM", valor: 0}
        ]
    }
];

const CONSEJOS = {
    1: [
        "Apoyar y promocionar iniciativas locales que busquen empoderar a las mujeres.",
        "Colaborar con organizaciones no lucrativas que trabajan en la promoción de la igualdad de género."
    ],
    2: [
        "Establecer políticas de contratación basadas en méritos y ofrecer flexibilidad en la jornada laboral.",
        "Crear un proceso de evaluación regular sobre el clima laboral para abordar posibles desigualdades de género."
    ],
    3: [
        "Establecer normativas claras sobre el lenguaje utilizado en espacios de trabajo y en reuniones y aplicar un sistema de sanciones en caso de uso de mensajes discriminatorios.",
        
    ],
    4: [
        "Proporcionar programas de capacitación para empleados en temas de género, diversidad e inclusión.",
        "Establecer un canal de denuncias seguro y confidencial para abordar problemas de discriminación"
    ],
    5: [
        "Establecer un seguimiento mensual para comprobar que los trabajadores que tengan contacto con clientes tengan un lenguaje adecuado, formal e igualitario para todos los géneros. La evaluación será realizada por los compañeros y el seguimiento de estas evaluaciones será llevada a cabo por un responsable del departamento de Recursos Humanos. El resultado será analizado y devuelto al trabajador evaluado con áreas de mejora."
    ],
    6: [
        "Adoptar programas de búsqueda activa de talento femenino",
        "Llegar a la proporción de un 50% de mujeres en los puestos directivos en un periodo de 3 años."
    ],
    7: [
        "Analizar datos internos de contratación para identificar brechas de género y comprender las razones detrás de ellas.",
        "Establecer métricas claras y objetivos relacionados con la contratación y promoción de mujeres, realizando un seguimiento regular del progreso."
    ],
    8: [
        "Realiza encuestas con el personal para comprender sus percepciones y experiencias relacionadas con la distribución de género en la asignación de roles y responsabilidades.",
        "1 día al mes el trabajador o trabajadora de un departamento sesgado por género explica y enseña sus trabajos a otro trabajador o trabajadora de otro departamento."
    ],
    9: [
        "Realiza encuestas con el personal para comprender sus percepciones y experiencias relacionadas con la distribución de género en la asignación de roles y responsabilidades.",
        "1 día al mes el trabajador o trabajadora de un departamento sesgado por género explica y enseña sus trabajos a otro trabajador o trabajadora de otro departamento."
    ],
    10: [
        "Realiza encuestas con el personal para comprender sus percepciones y experiencias relacionadas con la distribución de género en la asignación de roles y responsabilidades.",
        "1 día al mes el trabajador o trabajadora de un departamento sesgado por género explica y enseña sus trabajos a otro trabajador o trabajadora de otro departamento."
    ],
    11: [
        "Intentar utilizar palabras neutras que no indiquen el género (excepto si ya lo conocemos)."
    ],
    12: [
        "Team Buildings sobre desigualdad."
    ],
    13: [
        "La base de la publicidad es la empatía."
    ],
    14: [
        "Realizar mediante empresas externas diagnósticos de situación en materia de igualdad anual bianualmente."
    ],
    15: [
        "Realiza una política inclusiva que fomente la participación activa de los hombres en el cuidado y la crianza de sus hijos, dando la posibilidad de trabajar desde casa a las mujeres y hombres hasta que el bebé cumpla 1 año. Pasado este tiempo, y hasta los dos años de edad, los trabajadores y las trabajadoras tendrán la posibilidad de adoptar un esquema híbrido con hasta 2 días de trabajo desde casa."
    ],
    16: [
        "Realizar un manual de lenguaje no sexista que cualquier empleado o empleada podrá utilizar."
    ],
    17: [
        "Realiza sesiones de evaluación de las necesidades y preocupaciones de los empleados relacionados con la conciliación laboral y personal. Investiga qué políticas y prácticas se han podido aplicar en otras empresas similares a la tuya, y aprende de sus experiencias.",
        "Recomendaría implementar un servicio de guardería para empleados, dada la demanda potencial para mejorar el equilibrio entre trabajo y vida personal. Explorar convenios con guarderías cercanas podría ser una alternativa viable para ofrecer este apoyo sin gestionar una instalación interna, lo que podría contribuir a la satisfacción y retención de empleados."
    ],
    18: [
        "Recomendaría realizar sesiones de formación, evaluación de riesgos, recursos de apoyo y seguimiento continuo para adoptar el protocolo de prevención de riesgos psicosociales en la empresa."
    ],
    19: [
        "Sería recomendable establecer un sistema de denuncias anónimas y confidenciales, con accesibilidad para todo el mundo. Esto puede ser una solución efectiva para fomentar la comunicación y abordar las preocupaciones relacionadas con la integridad física o psíquica del personal."
    ],
    20: [
        "Implementar nuevas estrategias de mejora para los canales de denuncia para que su estructura sea sencilla para los trabajadores.",
        "Organizar charlas informativas para dar a conocer la importancia de los canales de denuncia y los beneficios que pueden aportar tener un buen ambiente laboral."
    ],
    21: [
        "Organizar charlas sobre la importancia de la salud mental y bienestar a tus empleados.",
        "Realiza alianzas con algún gabinete de psicología para que tus empleados puedan asistir en"
    ],
    22: [
        "Recomendaría implementar un servicio de guardería para empleados, dada la demanda potencial para mejorar el equilibrio entre trabajo y vida personal. Explorar convenios con guarderías cercanas podría ser una alternativa viable para ofrecer este apoyo sin gestionar una instalación interna, lo que podría contribuir a la satisfacción y retención de empleados."
    ],
    23: [
        "Implantar políticas formales de igualdad de género que incluyan la eliminación de las diferencias salariales que puedan existir en un mismo puesto de trabajo entre los distintos géneros, empezando con una investigación en los salarios de mujeres y hombres en roles parecidos y comprobar que no exista ninguna distinción."
    ],
    24: [
        "Establece métricas para medir el progreso hacia esos objetivos y revisa regularmente los resultados. Ofrece programas de desarrollo profesional y capacitación de liderazgo para mujeres empleadas que les ayude a avanzar en sus carreras y optar por esos roles."
    ],
    25: [
        "A la hora de iniciar un proceso de despidos deberían tener en cuenta que la habilidad y competencia de una persona no está determinada por su género."
    ],
    26: [
        "Dar a conocer a los trabajadores de la empresa la importancia que puede tener la elección de proveedores en función de si tiene en cuenta la igualdad de género, para poder respaldar de manera activa las prácticas inclusivas y mejorar en la construcción de un entorno laboral más equitativo."
    ],
    27: [
        "Puedes establecer un canal de denuncias confidencial y accesible para que los empleados puedan informar sobre cualquier incidente de acoso de género de manera segura, siempre actuando de manera rápida y adecuada."
    ],
    28: [
        "La flexibilidad horaria laboral es necesaria para que madres y padres puedan participar por igual en las labores del hogar y en la atención de sus hijos. Así se contribuye a la equidad de género y a la igualdad de oportunidades. Los trabajadores y trabajadoras de tu empresa pueden realizar el horario de ocho horas en la franja horaria que les ayude en la conciliación familiar y laboral, pero consensuado y aprobado por su responsable directo."
    ],
    29: [
        "Para asegurarte que en la contratación de los nuevos trabajadores no tienen en cuenta el género puedes revisar las políticas de contratación que disponen tus empleados responsables en esa función y comprobar que los criterios estén solamente basados en las habilidades, experiencia y competencias relacionadas con el puesto de trabajo."
    ],
    30: [
        "Reflexiona sobre el hecho de que ninguna norma debería buscar la discriminación positiva ni promover la existencia de cuotas, poniendo por delante el que impere la meritocracia a nivel profesional."
    ]
};

var contadorDivs = 0;
var divs = null;
var puntajeTotal = 0;
var consejosAlmacenados = []; // Almacena los consejos para mostrar al final
var resultadoDiv = null;

// Variable de control para verificar si los consejos están en pantalla
var consejosEnPantalla = false;

function mostrarConsejos() {
    // Establecer la variable de control a true cuando se muestran los consejos
    consejosEnPantalla = true;

    // Mostrar el div de consejos
    consejosDiv.style.display = 'block';

    // Después de 7 segundos, ocultar el div de consejos y permitir avanzar
    setTimeout(function () {
        consejosDiv.style.display = 'none';
        consejosEnPantalla = false; // Restablecer la variable de control a false
    }, 7000);
}

function mostrarResultado() {
    // Crear el div para mostrar la puntuación final
    resultadoDiv = document.createElement('div');
    resultadoDiv.setAttribute('class', 'resultado-div');
    resultadoDiv.style.width = '400px';

    // Mostrar el mensaje de acuerdo al puntaje total
    var mensaje = '';
    if (puntajeTotal < 75) {
        mensaje = 'MAL - ESPABILA';
    } else if (puntajeTotal >= 75 && puntajeTotal < 100) {
        mensaje = 'MEJORABLE - CONFIAMOS EN TI';
    } else if (puntajeTotal >= 100 && puntajeTotal < 140) {
        mensaje = 'POR EL BUEN CAMINO - SIGA TRABAJANDO EN ELLO';
    } else {
        mensaje = 'EXCELENTE - SIGUE ASÍ';
    }

    // Mostrar la puntuación total en el nuevo div
    resultadoDiv.textContent = 'Tu puntaje total es: ' + puntajeTotal + '\n' + mensaje;

    // Agregar el div de resultado al final de la sección 2
    document.getElementById('section2').appendChild(resultadoDiv);

    // Mostrar los consejos almacenados al final del cuestionario
    if (consejosAlmacenados.length > 0) {
        consejosDiv = document.createElement('div');
        consejosDiv.setAttribute('class', 'consejos-div');
        consejosDiv.style.width = '400px';

        consejosAlmacenados.forEach(function (consejo, index) {
            var consejoParrafo = document.createElement('p');
            consejoParrafo.textContent = index + '. ' + consejo;
            consejosDiv.appendChild(consejoParrafo);
        });

        // Agregar el div de consejos al final de la sección 2
        document.getElementById('section2').appendChild(consejosDiv);
    }
}

function adelante() {
    if (!consejosEnPantalla) {
        if (contadorDivs < preguntas.length) {
            // Obtener el valor seleccionado para esta pregunta
            var inputs = document.querySelectorAll('input[name="pregunta' + contadorDivs + '"]');
            var valorSeleccionado = 0;
            inputs.forEach(function(input) {
                if (input.checked) {
                    valorSeleccionado = parseInt(input.value);
                }
            });

            // Sumar el valor seleccionado al puntaje total
            puntajeTotal += valorSeleccionado;

            // Generar el div de consejos solo si el valor seleccionado es diferente de 5
            if (valorSeleccionado !== 5) {
                // Almacenar el consejo para mostrar al final
                var consejos = CONSEJOS[contadorDivs];
                if (consejos) {
                    consejos.forEach(function (consejo) {
                        consejosAlmacenados.push(consejo);
                    });
                }
            }

            contadorDivs++;

            // Ocultar la imagen y el botón
            document.getElementById('imagen').style.display = 'none';
            document.querySelector('.section1').style.display = 'none';

            // Crear nuevo div para la pregunta
            var nuevoDiv = document.createElement('div');
            nuevoDiv.setAttribute('class', 'nuevo-div');
            nuevoDiv.style.width = '400px'; // Establecer el ancho fijo para los nuevos divs

            // Crear el campo de pregunta
            var pregunta = document.createElement('p');
            pregunta.textContent = preguntas[contadorDivs - 1].pregunta;
            nuevoDiv.appendChild(pregunta);

            // Crear las opciones de la pregunta
            preguntas[contadorDivs - 1].respuestas.forEach(function (respuesta, index) {
                var label = document.createElement('label');
                var input = document.createElement('input');
                input.setAttribute('type', 'radio');
                input.setAttribute('name', 'pregunta' + contadorDivs);
                input.setAttribute('value', respuesta.valor); // Utilizamos el valor asignado a cada respuesta
                label.appendChild(input);
                label.appendChild(document.createTextNode(respuesta.opcion));
                nuevoDiv.appendChild(label);
                nuevoDiv.appendChild(document.createElement('br'));
            });

            // Agregar nuevo div al final de la sección 2
            document.getElementById('section2').appendChild(nuevoDiv);
            divs = document.getElementsByClassName('nuevo-div');
            divActual = divs[contadorDivs - 1];
            divActual.style.display = 'block';

            if (contadorDivs > 1) {
                for (var i = 0; i < divs.length - 1; i++) {
                    divs[i].style.display = 'none';
                }
            }
        } else {
            // Mostrar el resultado en lugar de la alerta
            mostrarResultado();

            // Ocultar el último div con la última pregunta
            var ultimaPreguntaDiv = divs[contadorDivs - 1];
            ultimaPreguntaDiv.style.display = 'none';
        }
    } else {
        alert('Espera a que se oculten los consejos antes de avanzar a la siguiente pregunta.');
    }
}

function bajarPregunta() {
    if (contadorDivs > 1) {
        divs[contadorDivs - 1].style.display = 'none';
        divs[contadorDivs - 2].style.display = 'block';
        contadorDivs--;
        // Eliminar el div de consejos si existe al retroceder
        if (consejosDiv) {
            consejosDiv.remove();
            consejosDiv = null;
        }
        // Eliminar el div de resultado si existe al retroceder
        if (resultadoDiv) {
            resultadoDiv.remove();
            resultadoDiv = null;
        }
    } else {
        alert('No hay más preguntas anteriores.');
    }
}
